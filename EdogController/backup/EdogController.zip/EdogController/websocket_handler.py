import asyncio
import json
from serial_manager import SerialManager
import math
import base64

serial_mgr = SerialManager()


async def send_rotation_data(websocket):
    t = 0
    while True:
        data = {
            "rotationX1": 0,
            "rotationX2": math.pi / 4 - math.pi,
            "rotationX3": math.pi / 2
        }
        await websocket.send(json.dumps({"type": "rotation", "data": data}))
        await asyncio.sleep(0.01)
        t += 0.001


async def read_serial_loop(websocket):
    print("[DEBUG] read_serial_loop démarrée")
    while serial_mgr.is_connected():
        try:
            data = serial_mgr.read_available()
            #print(f"[DEBUG] Lu : {repr(data)}")  # debug pur
            if data:
                await websocket.send(json.dumps({
                    "type": "serial_read",
                    "data": data
                }))
        except Exception as e:
            await websocket.send(json.dumps({
                "type": "serial_read_error",
                "error": str(e)
            }))
            break
        await asyncio.sleep(0.01)


async def websocket_handler(websocket):
    send_task = asyncio.create_task(send_rotation_data(websocket))
    read_task = None

    try:
        async for message in websocket:
            try:
                msg = json.loads(message)
            except json.JSONDecodeError:
                continue

            if msg.get("type") == "get_ports":
                ports = serial_mgr.list_ports()
                await websocket.send(json.dumps({"type": "ports", "ports": ports}))

            elif msg.get("type") == "connect":
                try:
                    serial_mgr.connect(msg.get("port"))
                    read_task = asyncio.create_task(read_serial_loop(websocket))
                    await websocket.send(json.dumps({"type": "connect_ack", "success": True, "port": msg.get("port")}))
                except Exception as e:
                    await websocket.send(
                        json.dumps({"type": "connect_ack", "success": False, "port": msg.get("port"), "error": str(e)}))

            elif msg.get("type") == "disconnect":
                serial_mgr.disconnect()
                if read_task:
                    read_task.cancel()
                await websocket.send(json.dumps({"type": "disconnect_ack", "success": True}))

            elif msg.get("type") == "serialMessage":
                try:
                    serial_mgr.send(msg.get("message", ""))
                except Exception as e:
                    await websocket.send(json.dumps({"type": "serialMessage_error", "error": str(e)}))

            elif msg.get("type") == "fichier":
                try:
                    monFichier = msg.get("data")

                    print(monFichier)

                    encoded = base64.b64decode(monFichier)
                    file = open('firmware.bin', 'wb')
                    file.write((encoded))
                    file.close()

                except Exception as e:
                    await websocket.send(json.dumps({"type": "file_error", "error": str(e)}))


    except:
        pass
    finally:
        serial_mgr.disconnect()
        send_task.cancel()
        if read_task:
            read_task.cancel()